//
//  TreesCollectionViewCell.swift
//  Holiday App
//
//  Created by Jenya Lebid on 10/17/20./Users/jenya/Desktop/Holiday App/Holiday App/Trees1CollectionViewCell.swift
//

import UIKit

class Trees1CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var treeTypeImage: UIImageView!
    @IBOutlet weak var treeTypeLabel: UILabel!
    

    
}
